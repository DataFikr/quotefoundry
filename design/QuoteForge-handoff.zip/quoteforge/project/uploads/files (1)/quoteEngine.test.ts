// ============================================================================
// quoteEngine.test.ts — locks the canonical math so screen & save never drift
// ============================================================================
import { computeQuote } from './quoteEngine';
import type { QuoteInputs, ShopRates } from './types';

const rates: ShopRates = {
  rate_cutting: 75, rate_fitting: 80, rate_welding: 90, rate_finishing: 65,
  rate_burn: 120, price_steel: 0.85, scrap_pct: 15, rate_consumables: 12,
  overhead_pct: 18, margin_pct: 30,
};

const inputs: QuoteInputs = {
  job_name: 'Stair stringers',
  material_weight: 240, quantity: 1, burn_minutes: 35,
  hrs_cutting: 1.5, hrs_fitting: 3, hrs_welding: 4, hrs_finishing: 1.5,
  outside_services: 85,
};

const t = computeQuote(inputs, rates);

// Canonical expected values, derived from the formula (not hand-typed):
//   material   = 240 * 0.85 * 1.15            = 234.60
//   labor      = 112.5 + 240 + 360 + 97.5     = 810.00
//   burn       = (35/60) * 120                = 70.00
//   consumables= 4 * 12                        = 48.00
//   cost       = 234.60+810+70+48+85          = 1247.60
//   overhead   = 1247.60 * 0.18              = 224.57
//   margin     = (1247.60+224.57) * 0.30     = 441.65
//   price      = 1472.17 + 441.65            = 1913.82
const expect = {
  line_material: 234.6, line_labor: 810, line_burn: 70, line_consumables: 48,
  total_cost: 1247.6, total_overhead: 224.57, total_margin: 441.65,
  quoted_price: 1913.82,
};
let failures = 0;
for (const [k, v] of Object.entries(expect)) {
  const got = (t as any)[k];
  if (got !== v) { console.error(`FAIL ${k}: expected ${v}, got ${got}`); failures++; }
}
console.log(failures === 0 ? 'PASS: engine matches canonical values' : `${failures} mismatch(es)`);
